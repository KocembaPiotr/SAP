SAP_APP_PATH = r'C:\Program Files\SAP\FrontEnd\SAPGUI\\'
SAP_APP_FILE = 'saplogon.exe'
SAP_TMP_PATH = r'C:\temp\\'
SAP_TMP_FILE = 'tmp.txt'
SAP_TC_COOIS_ROW_START = 0
SAP_TC_MB52_ROW_START = 0
SAP_TC_ZCS11H_ROW_START = 3