from sapgui import sapgui
from sapgui import sapguicode
from sapgui import sapguiparam