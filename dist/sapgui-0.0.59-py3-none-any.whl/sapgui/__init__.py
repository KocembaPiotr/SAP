from sapgui import sapgui
from sapgui import sapguicode